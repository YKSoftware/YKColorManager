﻿namespace YKColorCapture.Model
{
    using System.Windows.Media;
    using YKColorCapture.Core;

    public class ColorItem : NotificationObject
    {
        public ColorItem(int index)
        {
            Index = index;
        }

        public int Index { get; private set; }

        private Color color;
        /// <summary>
        /// Color 構造体を取得または設定する
        /// </summary>
        public Color Color
        {
            get { return color; }
            set
            {
                if (SetProperty(ref color, value, "Color"))
                {
                    RaisePropertyChanged("R");
                    RaisePropertyChanged("G");
                    RaisePropertyChanged("B");
                }
            }
        }

        private byte r;
        /// <summary>
        /// R チャンネルを取得または設定する
        /// </summary>
        public byte R
        {
            get { return Color.R; }
            set
            {
                r = value;
                Color = Color.FromArgb(0xff, R, G, B);
            }
        }

        private byte g;
        /// <summary>
        /// G チャンネルを取得または設定する
        /// </summary>
        public byte G
        {
            get { return Color.G; }
            set
            {
                g = value;
                Color = Color.FromArgb(0xff, R, G, B);
            }
        }

        private byte b;
        /// <summary>
        /// B チャンネルを取得または設定する
        /// </summary>
        public byte B
        {
            get { return Color.B; }
            set
            {
                b = value;
                Color = Color.FromArgb(0xff, R, G, B);
            }
        }

    }
}
