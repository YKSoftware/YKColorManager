﻿namespace YKColorCapture.ViewModel
{
    using YKColorCapture.Core;

    public class ViewModelBase : NotificationObject
    {
    }
}
