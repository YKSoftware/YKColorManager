﻿namespace YKColorCapture.ViewModel
{
    using System.Collections.ObjectModel;
    using System.Linq;
    using System.Reflection;
    using YKColorCapture.Core;
    using YKColorCapture.Model;

    public class MainViewModel : ViewModelBase
    {
        public MainViewModel()
        {
            ColorItems.Add(new ColorItem(1));
        }

        #region プロパティ
        /// <summary>
        /// タイトルを取得する
        /// </summary>
        public string Title
        {
            get { return ProductInfo.Instance.Title; }
        }

        private ObservableCollection<ColorItem> colorItems = new ObservableCollection<ColorItem>();
        /// <summary>
        /// 色情報コレクションを取得または設定する
        /// </summary>
        public ObservableCollection<ColorItem> ColorItems
        {
            get { return colorItems; }
            set { SetProperty(ref colorItems, value, "ColorItems"); }
        }

        private DelegateCommand addItemCommand;
        /// <summary>
        /// 色情報コレクション追加コマンドを取得する
        /// </summary>
        public DelegateCommand AddItemCommand
        {
            get
            {
                if (addItemCommand == null)
                    addItemCommand = new DelegateCommand(p =>
                    {
                        ColorItems.Add(new ColorItem(ColorItems.Count + 1));
                    });
                return addItemCommand;
            }
        }

        private DelegateCommand deleteItemCommand;
        /// <summary>
        /// 色情報コレクション削除コマンドを取得する
        /// </summary>
        public DelegateCommand DeleteItemCommand
        {
            get
            {
                if (deleteItemCommand == null)
                    deleteItemCommand = new DelegateCommand(p =>
                    {
                        if (ColorItems.Count > 1)
                            ColorItems.Remove(ColorItems.Last());
                    });
                return deleteItemCommand;
            }
        }

        private DelegateCommand versionCommand;
        public DelegateCommand VersionCommand
        {
            get
            {
                return versionCommand ?? (versionCommand = new DelegateCommand(_ =>
                {
                    var p = ProductInfo.Instance;
                    var str = string.Format("{0} Ver.{1}", p.Product, p.VersionString);
                    YKToolkit.Controls.MessageBox.Show(str, "バージョン情報", YKToolkit.Controls.MessageBoxButton.OK, YKToolkit.Controls.MessageBoxImage.Information);
                }));
            }
        }
        #endregion  // プロパティ
    }
}
