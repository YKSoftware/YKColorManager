﻿namespace YKColorCapture.View.Behaviors
{
    using System;
    using System.Runtime.InteropServices;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Input;
    using System.Windows.Media;

    class ColorUnderCursorBehavior
    {
        #region properties
        public static readonly DependencyProperty SelectedColorProperty = DependencyProperty.RegisterAttached("SelectedColor", typeof(Color), typeof(ColorUnderCursorBehavior), new FrameworkPropertyMetadata(Colors.White, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault));
        /// <summary>
        /// 取得した色を取得する
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static Color GetSelectedColor(DependencyObject target)
        {
            return (Color)target.GetValue(SelectedColorProperty);
        }
        /// <summary>
        /// 取得した色を設定する
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>
        public static void SetSelectedColor(DependencyObject target, Color value)
        {
            target.SetValue(SelectedColorProperty, value);
        }

        public static readonly DependencyProperty IsEnabledProperty = DependencyProperty.RegisterAttached("IsEnabled", typeof(bool), typeof(ColorUnderCursorBehavior), new FrameworkPropertyMetadata(false, OnIsEnabledChanged));
        /// <summary>
        /// 色取得が有効かどうか確認する
        /// </summary>
        /// <param name="target"></param>
        /// <returns></returns>
        public static bool GetIsEnabled(DependencyObject target)
        {
            return (bool)target.GetValue(IsEnabledProperty);
        }
        /// <summary>
        /// 色取得の有効/無効を設定する
        /// </summary>
        /// <param name="target"></param>
        /// <param name="value"></param>
        public static void SetIsEnabled(DependencyObject target, bool value)
        {
            target.SetValue(IsEnabledProperty, value);
        }
        #endregion  // properties

        #region methods
        /// <summary>
        /// 色取得の有効/無効変更イベントハンドラ
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private static void OnIsEnabledChanged(DependencyObject sender, DependencyPropertyChangedEventArgs e)
        {
            var control = sender as Button;
            control.PreviewMouseLeftButtonDown += AssociatedObject_PreviewMouseLeftButtonDown;
            control.PreviewMouseLeftButtonUp += AssociatedObject_PreviewMouseLeftButtonUp;
            control.PreviewMouseMove += AssociatedObject_PreviewMouseMove;
        }

        private static void AssociatedObject_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            var control = sender as Button;
            control.CaptureMouse();
        }

        private static void AssociatedObject_PreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            var control = sender as Button;
            if (control.IsMouseCaptured)
            {
                control.ReleaseMouseCapture();
            }
        }

        private static void AssociatedObject_PreviewMouseMove(object sender, MouseEventArgs e)
        {
            var control = sender as Button;
            if (control.IsMouseCaptured)
            {
                control.SetValue(SelectedColorProperty, GetColorUnderCursor());
            }
        }
        #endregion  // methods

        #region 色取得
        [DllImport("gdi32")]
        public static extern uint GetPixel(IntPtr hDC, int XPos, int YPos);

        [DllImport("user32.dll", CharSet = CharSet.Auto)]
        public static extern bool GetCursorPos(out POINT pt);

        [DllImport("User32.dll", CharSet = CharSet.Auto)]
        public static extern IntPtr GetWindowDC(IntPtr hWnd);

        /// <summary>
        /// Gets the System.Drawing.Color from under the mouse cursor.
        /// </summary>
        /// <returns>The color value.</returns>
        public static Color GetColorUnderCursor()
        {
            IntPtr dc = GetWindowDC(IntPtr.Zero);

            POINT p;
            GetCursorPos(out p);

            long color = GetPixel(dc, p.X, p.Y);
            byte a = 0xff;
            byte r = (byte)(color & 0x000000ff);            // なぜか r と b が逆。
            byte g = (byte)((color & 0x0000ff00) >> 8);
            byte b = (byte)((color & 0x00ff0000) >> 16);
            return Color.FromArgb(a, r, g, b);
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct POINT
        {
            public int X;
            public int Y;
            public POINT(int x, int y)
            {
                X = x;
                Y = y;
            }
        }
        #endregion  // 色取得
    }
}
