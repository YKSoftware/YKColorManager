﻿namespace YKColorCapture
{
    using System.Windows;
    using YKColorCapture.View;

    /// <summary>
    /// App.xaml の相互作用ロジック
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            var w = new MainView();
            w.Show();
        }
    }
}
