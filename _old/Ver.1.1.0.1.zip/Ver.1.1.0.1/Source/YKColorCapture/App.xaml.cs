﻿namespace YKColorCapture
{
    using System.Windows;
    using YKColorCapture.View;
    using YKToolkit.Themes;

    /// <summary>
    /// App.xaml の相互作用ロジック
    /// </summary>
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);

            YKToolkit.Themes.ThemeManager.Initialize();

            var w = new MainView();
            w.Show();
        }
    }
}
