﻿namespace YKColorCapture.Core
{
    using System.ComponentModel;

    public class NotificationObject : INotifyPropertyChanged
    {
        private PropertyChangedEventHandler propertyChanged;

        public event PropertyChangedEventHandler PropertyChanged
        {
            add { propertyChanged += value; }
            remove { propertyChanged -= value; }
        }

        protected virtual void RaisePropertyChanged(string propertyName)
        {
            var h = propertyChanged;
            if (h != null)
                h(this, new PropertyChangedEventArgs(propertyName));
        }

        protected virtual bool SetProperty<T>(ref T target, T value, string propertyName)
        {
            if (Equals(target, value))
                return false;
            target = value;
            RaisePropertyChanged(propertyName);
            return true;
        }
    }
}
